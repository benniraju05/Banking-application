import tkinter as tk
from tkinter import messagebox

class Account:
    def __init__(self, account_number, name, age, gender, mobile_number, balance=0.0):
        self.account_number = account_number
        self.name = name
        self.age = age
        self.gender = gender
        self.mobile_number = mobile_number
        self.balance = balance
        self.transaction_history = []

    def deposit(self, amount):
        if amount > 0:
            self.balance += amount
            self.transaction_history.append(f"Deposited ${amount:.2f}")
        else:
            raise ValueError("Deposit amount must be positive")

    def withdraw(self, amount):
        if 0 < amount <= self.balance:
            self.balance -= amount
            self.transaction_history.append(f"Withdrew ${amount:.2f}")
        else:
            raise ValueError("Invalid withdrawal amount")

class Bank:
    def __init__(self):
        self.accounts = {}

    def create_account(self, account_number, name, age, gender, mobile_number, initial_deposit=0.0):
        if account_number in self.accounts:
            raise ValueError("Account number already exists")
        new_account = Account(account_number, name, age, gender, mobile_number, initial_deposit)
        self.accounts[account_number] = new_account

    def get_account(self, account_number):
        return self.accounts.get(account_number)

class AccountWindow:
    def __init__(self, bank, welcome_screen):
        self.bank = bank
        self.welcome_screen = welcome_screen
        self.root = tk.Tk()
        self.root.title("Create Account")
        
        # Set minimum and maximum window size
        self.root.minsize(800,600)
        self.root.maxsize(1000,800)

        self.create_widgets()
        self.root.mainloop()

    def create_widgets(self):
        # Set background and foreground colors
        bg_color = "darkgreen"
        fg_color = "white"
        
        self.root.configure(bg=bg_color)

        self.account_number_label = tk.Label(self.root, text="Account Number", bg=bg_color, fg=fg_color,font=("Courier", 16))
        self.account_number_label.pack(pady=(10,5))

        self.account_number_entry = tk.Entry(self.root)
        self.account_number_entry.pack(pady=(0,10))

        self.owner_label = tk.Label(self.root, text="Name", bg=bg_color, fg=fg_color,font=("Courier", 16))
        self.owner_label.pack(pady=(0,5))

        self.owner_entry = tk.Entry(self.root)
        self.owner_entry.pack(pady=(0,10))

        self.age_label = tk.Label(self.root, text="Age", bg=bg_color, fg=fg_color,font=("Courier", 16))
        self.age_label.pack(pady=(0,5))

        self.age_entry = tk.Entry(self.root)
        self.age_entry.pack(pady=(0,10))

        self.gender_label = tk.Label(self.root, text="Gender", bg=bg_color, fg=fg_color,font=("Courier", 16))
        self.gender_label.pack(pady=(0,5))

        self.gender_entry = tk.Entry(self.root)
        self.gender_entry.pack(pady=(0,10))

        self.mobile_number_label = tk.Label(self.root, text="Mobile Number", bg=bg_color, fg=fg_color,font=("Courier", 16))
        self.mobile_number_label.pack(pady=(0,5))

        self.mobile_number_entry = tk.Entry(self.root)
        self.mobile_number_entry.pack(pady=(0,10))

        self.initial_deposit_label = tk.Label(self.root, text="Initial Deposit", bg=bg_color, fg=fg_color,font=("Courier", 16))
        self.initial_deposit_label.pack(pady=(0,5))

        self.initial_deposit_entry = tk.Entry(self.root)
        self.initial_deposit_entry.pack(pady=(0,10))

        self.create_account_button = tk.Button(self.root, text="Create Account", command=self.create_account, bg="yellow", fg="black",font=("Courier", 16))
        self.create_account_button.pack(pady=(10,5), padx=20)

        self.back_button = tk.Button(self.root, text="Back", command=self.go_back, bg="red", fg="white",font=("Courier", 16))
        self.back_button.pack(pady=5, padx=20)

    def create_account(self):
        account_number = self.account_number_entry.get()
        name = self.owner_entry.get()
        age = self.age_entry.get()
        gender = self.gender_entry.get()
        mobile_number = self.mobile_number_entry.get()
        try:
            initial_deposit = float(self.initial_deposit_entry.get())
            self.bank.create_account(account_number, name, age, gender, mobile_number, initial_deposit)
            messagebox.showinfo("Success", "Account created successfully")
        except ValueError as e:
            messagebox.showerror("Error", str(e))

    def go_back(self):
        self.root.destroy()
        self.welcome_screen.show()

class TransactionWindow:
    def __init__(self, bank, welcome_screen):
        self.bank = bank
        self.welcome_screen = welcome_screen
        self.root = tk.Tk()
        self.root.title("Bank")
        
        # Set minimum and maximum window size
        self.root.minsize(800, 600)
        self.root.maxsize(1000, 800)

        self.create_widgets()
        self.root.mainloop()

    def create_widgets(self):
        # Set background and foreground colors
        bg_color = "darkblue"
        fg_color = "yellow"
        
        self.root.configure(bg=bg_color)

        self.transaction_label = tk.Label(self.root, text="--- Bank Account ---", bg=bg_color, fg=fg_color, font=("Courier", 18))
        self.transaction_label.pack(pady=(10,5))

        self.transaction_account_number_label = tk.Label(self.root, text="Account Number", bg=bg_color, fg=fg_color, font=("Courier", 16))
        self.transaction_account_number_label.pack(pady=(0,5))

        self.transaction_account_number_entry = tk.Entry(self.root)
        self.transaction_account_number_entry.pack(pady=(0,10))

        self.check_account_button = tk.Button(self.root, text="Check Account", command=self.check_account, bg="lightgreen", fg="black", font=("Courier", 16))
        self.check_account_button.pack(pady=(10,5), padx=20)

        self.customer_details_label = tk.Label(self.root, text="Customer Details", bg=bg_color, fg=fg_color, font=("Courier", 16))
        self.customer_details_label.pack(pady=(0,5))

        self.customer_details_text = tk.Text(self.root, height=6, width=50)
        self.customer_details_text.pack(pady=(0,10))

        self.amount_label = tk.Label(self.root, text="Amount", bg=bg_color, fg=fg_color, font=("Courier", 16))
        self.amount_label.pack(pady=(0,5))

        self.amount_entry = tk.Entry(self.root)
        self.amount_entry.pack(pady=(0,10))

        self.deposit_button = tk.Button(self.root, text="Deposit", command=self.deposit, bg="lightgreen", fg="black", font=("Courier", 16))
        self.deposit_button.pack(pady=10, padx=20)

        self.withdraw_button = tk.Button(self.root, text="Withdraw", command=self.withdraw, bg="lightgreen", fg="black", font=("Courier", 16))
        self.withdraw_button.pack(pady=(0,10))

        self.transaction_history_label = tk.Label(self.root, text="Transaction History", bg=bg_color, fg=fg_color, font=("Courier", 16))
        self.transaction_history_label.pack(pady=(0,5))

        self.transaction_history_text = tk.Text(self.root, height=10, width=50)
        self.transaction_history_text.pack(pady=(0,10))

        self.back_button = tk.Button(self.root, text="Back", command=self.go_back, bg="red", fg="white", font=("Courier", 16))
        self.back_button.pack(pady=10, padx=20)

    def check_account(self):
        account_number = self.transaction_account_number_entry.get()
        account = self.bank.get_account(account_number)
        if account:
            details = (f"Account Number: {account.account_number}\n"
            f"Name: {account.name}\n"
            f"Age: {account.age}\n"
            f"Gender: {account.gender}\n"
            f"Mobile Number: {account.mobile_number}\n"
            f"Balance: ${account.balance:.2f}"
            )
            self.customer_details_text.delete(1.0, tk.END)
            self.customer_details_text.insert(tk.END, details)

            self.transaction_history_text.delete(1.0, tk.END)
            for transaction in account.transaction_history:
                self.transaction_history_text.insert(tk.END, transaction + "\n")
        else:
            messagebox.showerror("Error", "Account not found")

    def deposit(self):
        account_number = self.transaction_account_number_entry.get()
        try:
            amount = float(self.amount_entry.get())
            account = self.bank.get_account(account_number)
            if account:
                account.deposit(amount)
                messagebox.showinfo("Success", f"Deposited ${amount:.2f} to account {account_number}")
                self.check_account()
            else:
                messagebox.showerror("Error", "Account not found")
        except ValueError as e:
            messagebox.showerror("Error", str(e))

    def withdraw(self):
        account_number = self.transaction_account_number_entry.get()
        try:
            amount = float(self.amount_entry.get())
            account = self.bank.get_account(account_number)
            if account:
                account.withdraw(amount)
                messagebox.showinfo("Success", f"Withdrew ${amount:.2f} from account {account_number}")
                self.check_account()
            else:
                messagebox.showerror("Error", "Account not found")
        except ValueError as e:
            messagebox.showerror("Error", str(e))

    def go_back(self):
        self.root.destroy()
        self.welcome_screen.show()

class WelcomeScreen:
    def __init__(self):
        self.root = tk.Tk()
        self.root.title("Banking System")
        
        # Set minimum and maximum window size
        self.root.minsize(800, 600)
        self.root.maxsize(1000, 800)

        self.create_widgets()
        self.root.mainloop()

    def create_widgets(self):
        # Set background and foreground colors
        bg_color = "darkred"
        fg_color = "white"
        
        self.root.configure(bg=bg_color)

        self.welcome_label = tk.Label(self.root, text="Welcome to the Banking System", bg=bg_color, fg=fg_color, font=("Courier", 24))
        self.welcome_label.pack(pady=20)

        self.create_account_button = tk.Button(self.root, text="Create Account", command=self.open_account_window, bg="orange", fg="black", font=("Courier", 18))
        self.create_account_button.pack(pady=(10, 20), padx=20)

        self.transaction_button = tk.Button(self.root, text="Transactions", command=self.open_transaction_window, bg="orange", fg="black", font=("Courier", 18))
        self.transaction_button.pack(pady=(10, 20), padx=20)

    def open_account_window(self):
        self.root.destroy()
        AccountWindow(bank, self)

    def open_transaction_window(self):
        self.root.destroy()
        TransactionWindow(bank, self)

    def show(self):
        self.__init__()

if __name__ == "__main__":
    bank = Bank()
    WelcomeScreen()
